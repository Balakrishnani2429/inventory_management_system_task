<?php
// MODEL: Product_model.php
class Product_model extends CI_Model {
    public function get_all() {
        return $this->db->get('products')->result();
    }

    public function get($id) {
        return $this->db->get_where('products', ['id' => $id])->row();
    }

    public function insert_update_datas() {
        $id = $this->input->post('id');

        $common_datas = array(
            'name'  => $this->input->post('name'),
            'sku'   => $this->input->post('sku'),
            'price' => $this->input->post('price')
        );
        
        if (empty($id)) :
            $this->db->insert('products', $common_datas); // Insert new record
        else :
            $this->db->where('id', $id)->update('products', $common_datas); // Update existing record
        endif;
        
    }

    public function delete($id) {
        $this->db->delete('products', ['id' => $id]);
    }
}
?>