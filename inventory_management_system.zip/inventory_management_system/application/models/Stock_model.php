<?php
// MODEL: Stock_model.php
class Stock_model extends CI_Model {
    public function insert($data) {
        $this->db->insert('stock_transactions', [
            'product_id' => $data['product_id'],
            'type' => $data['type'],
            'quantity' => $data['quantity'],
            'date' => date('Y-m-d')
        ]);
    }

    public function get_stock_report() {
        $this->db->select("p.id, p.name, p.sku,
            SUM(CASE WHEN st.type = 'in' THEN st.quantity ELSE 0 END) - 
            SUM(CASE WHEN st.type = 'out' THEN st.quantity ELSE 0 END) AS available_stock");
        $this->db->from('products p');
        $this->db->join('stock_transactions st', 'p.id = st.product_id', 'left');
        $this->db->group_by('p.id');
        return $this->db->get()->result();
    }
}
?>