<?php
class Products extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('Product_model');
        $this->load->model('Stock_model');
    }

    public function index() {
        $data['products'] = $this->Product_model->get_all();
        $this->load->view('templates/header');
        $this->load->view('products/list', $data);
        $this->load->view('templates/footer');
    }
    public function add_edit_product($id=null) {
        $get_product_datas  = $this->Product_model->get($id);
        if(!empty($id)):
            $data['id']     = $get_product_datas->id;
            $data['name']   = $get_product_datas->name;
            $data['sku']    = $get_product_datas->sku;
            $data['price']  = $get_product_datas->price;
        else:
            $data['id']     = "";
            $data['name']   = "";
            $data['sku']    = "";
            $data['price']  = "";
        endif;
        $this->load->view('templates/header');
        $this->load->view('products/form', $data);
        $this->load->view('templates/footer');
    }

    function view_chart()
    {
        $data['report'] = $this->Stock_model->get_stock_report();
        $this->load->view('templates/header');
        $this->load->view('products/view_chart', $data);
        $this->load->view('templates/footer');
    }
    public function insert_update_datas() {
        $this->Product_model->insert_update_datas();
        redirect('products');
    }

    public function delete($id) {
        $this->Product_model->delete($id);
        redirect('products');
    }
}
?>