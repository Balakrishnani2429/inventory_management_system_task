<div class="container mt-4">
    <h2><?= !empty($id) ? 'Edit' : 'Add' ?> Product</h2>
    <form method="post" action="<?= base_url('products/insert_update_datas') ?>">
        <input type="hidden" value="<?=$id?>" name="id">
        <div class="form-group">
            <label>Name</label>
            <input type="text" name="name" class="form-control" value="<?= $name ?>" required>
        </div>
        <div class="form-group">
            <label>SKU</label>
            <input type="text" name="sku" class="form-control" value="<?= $sku ?>" required>
        </div>
        <div class="form-group">
            <label>Price</label>
            <input type="number" step="0.01" name="price" class="form-control" value="<?= $price ?>" required>
        </div>
        <button class="btn btn-success">Submit</button>
        <a href="<?= base_url('products/') ?>" class="btn btn-primary">Back</a>
    </form>
</div>