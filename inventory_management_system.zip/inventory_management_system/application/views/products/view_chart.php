<a href="<?= base_url('products/') ?>" class="btn btn-primary">Back</a>

<div class="container mt-4">
  <h3>Stock Report</h3>
  <canvas id="stockChart" height="100"></canvas>
</div>

<script>
    window.onload = function () {
  var ctx = document.getElementById('stockChart').getContext('2d');
  var stockChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: <?= json_encode(array_column($report, 'name')) ?>,
      datasets: [{
        label: 'Available Stock',
        data: <?= json_encode(array_column($report, 'available_stock')) ?>,
        backgroundColor: 'rgba(54, 162, 235, 0.7)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: 'Quantity'
          }
        }
      }
    }
  });};
</script>
