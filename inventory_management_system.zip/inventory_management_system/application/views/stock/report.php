<div class="container mt-4">
    <h2>Stock Report</h2>
    <a href="<?= base_url('products/view_chart/' . $report[0]->id) ?>" class="btn btn-sm btn-success">View Chart</a>

    <table class="table table-bordered">
        <thead>
            <tr><th>ID</th><th>Name</th><th>SKU</th><th>Available Stock</th></tr>
        </thead>
        <tbody>
            <?php foreach ($report as $row): ?>
            <tr>
                <td><?= $row->id ?></td>
                <td><?= $row->name ?></td>
                <td><?= $row->sku ?></td>
                <td><?= $row->available_stock ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

