
<div class="container mt-4">
    <h2>Stock In/Out</h2>
    <form method="post">
        <div class="form-group">
            <label>Product</label>
            <select name="product_id" class="form-control" required>
                <?php foreach ($products as $p): ?>
                <option value="<?= $p->id ?>"><?= $p->name ?> (<?= $p->sku ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Type</label>
            <select name="type" class="form-control">
                <option value="in">Stock In</option>
                <option value="out">Stock Out</option>
            </select>
        </div>
        <div class="form-group">
            <label>Quantity</label>
            <input type="number" name="quantity" class="form-control" required>
        </div>
        <button class="btn btn-success">Submit</button>
        <a href="<?= base_url('products/') ?>" class="btn btn-primary">Back</a>

    </form>
</div>