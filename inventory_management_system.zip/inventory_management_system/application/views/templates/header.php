<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<!-- Add this in your header.php before closing </head> -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand d-flex align-items-center" href="<?= base_url('products') ?>">
      <i class="bi bi-box-seam me-2"></i>Inventory
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarMenu">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="<?= base_url('products') ?>">
            <i class="bi bi-bag me-1"></i> Products
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= base_url('stock/form') ?>">
            <i class="bi bi-arrow-left-right me-1"></i> Stock In/Out
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= base_url('stock/report') ?>">
            <i class="bi bi-clipboard-data me-1"></i> Stock Report
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-4">